package com.mak.redis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpingDataRedisApplicationTests {

    @Test
    void contextLoads() {
    }

}
